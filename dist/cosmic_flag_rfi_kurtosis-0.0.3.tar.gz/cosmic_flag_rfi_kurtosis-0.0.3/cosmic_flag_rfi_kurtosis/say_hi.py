def say_hi(x):
	print("Hello world!")
	print(f"You chose x = {x}")
